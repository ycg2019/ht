## 常用选择器

```js
/**
 * 元素选择器 : 根据标签名选中一组元素
 *   span {
 *     background-color: DodgerBlue;
 *   }
 * 
 * id 选择器 : 根据元素的 id 属性值选中一个元素
 *   #identified {
 *     background-color: DodgerBlue;
 *   }
 * 
 * 类选择器 : 根据元素的 class 属性值选中一组元素
 *   .classy {
 *     background-color: DodgerBlue;
 *   }
 * 
 * 通配选择器 : 选中页面中的所有元素
 *   * {
 *     background-color: DodgerBlue;
 *   }
 */
```

## 复合选择器

```js
/**
 * 交集选择器 : 选中同时满足多个条件的元素 -- 如果有元素选择器，必须使用元素选择器开头
 *   selector1selector2...selectorN {
 *     background-color: DodgerBlue;
 *   }
 * 
 * 并集选择器 : 元素只要满足其中一个条件就被选中
 *   selector1, selector2, ..., selectorN {
 *     background-color: DodgerBlue;
 *   }
 * 
 */
```

## 关系选择器

```js
/**
 * 子代元素选择器 : 选中指定元素的指定子代元素
 *   selector1 > selector2 > ... > selectorN {
 *     background-color: DodgerBlue;
 *   }
 * 
 * 后代元素选择器 : 选中指定元素的指定后代元素
 *   selector1 selector2 ... selectorN {
 *     background-color: DodgerBlue;
 *   }
 * 
 * 相邻兄弟选择器 : 指定元素的相邻兄弟元素，若满足条件则被选中
 *   former_element + target_element {
 *     background-color: DodgerBlue;
 *   }
 * 
 * 通用兄弟选择器 : 指定元素的全部兄弟元素，若满足条件则被选中
 *   former_element ~ target_element {
 *     background-color: DodgerBlue;
 *   }
 * 
 * 注 : 这里的兄弟元素只计算后面的，不计算前面的
 */
```

## 属性选择器

```js
/**
 * [属性名] -- 选择含有指定属性的元素
 *   a[title] { color: purple; }
 *     
 * [属性名=属性值] -- 选择含有指定属性和属性值的元素
 *   a[href="https://example.org"] { color: purple; }
 * 
 * [属性名^=属性值] -- 选择属性值以指定值开头的元素
 *   a[href^="https://"] { color: purple; }
 * 
 * [属性名$=属性值] -- 选择属性值以指定值结尾的元素
 *   a[href$=".org"] { color: purple; }
 * 
 * [属性名*=属性值] -- 选择属性值中含有某值的元素
 *   a[href*="example"] { color: purple; }
 */
```

## 伪类选择器

```js
/**
 * 伪类 : 用于描述元素的一些特殊状态
 * 
 * :first-child -- 指定元素在一组兄弟中是第一个元素，则选中
 *   p:first-child { background-color: black; }
 * :last-child -- 指定元素在一组兄弟中是最后一个元素，则选中
 *   p:first-child { background-color: white; }
 * :nth-child(an+b) -- 指定元素在一组兄弟中是第 an+b 个元素 (a,b 为整数，n={0, 1, 2, 3...})，则选中
 *   tr:nth-child(2n+1)  -- 选中表格的基数行
 *   tr:nth-child(odd)   -- 选中表格的基数行
 *   tr:nth-child(2n)    -- 选中表格的偶数行
 *   tr:nth-child(even)  -- 选中表格的偶数行
 * 
 * :first-of-type      -- 选中在一组兄弟中的第一个该类型的元素
 * :last-of-type       -- 选中在一组兄弟中的最后一个该类型的元素
 * :nth-of-type(an+b)  -- 选中在一组兄弟中的第 an+b 个该类型的元素
 * 
 * :not() -- 指定元素不满足指定条件，则选中
 *   selector1:not(selector2) { color: green; }
 * 
 * :empty -- 指定元素为空元素，则选中
 *   selector:empty { color: green; }
 */
```

```js
/**
 * 特殊的伪类
 * 1.未访问过的链接  --  a:link { ... }
 * 2.已访问过的链接  --  a:visited { color: xxx; }
 *   注: 链接访问后，会涉及用户隐私，所有只能设置字体颜色
 * 3.鼠标滑过的链接  --  a:hover { ... }
 * 4.鼠标点击的链接  --  a:active { ... }
 * 5.可编辑的表单    --  input:enabled { ... }
 * 6.被禁用的表单    --  input:disabled { ... }
 * 7.被选中的表单    --  input:checked { ... }
 * 8.获得焦点的表单  --  input:focus { ... }
 */
```

## 伪元素选择器

```js
/**
 * 伪元素 : 用于表示元素的一些特殊位置
 * 
 * ::first-letter -- 选中块元素的首字母
 *   p::first-letter { font-size: 130%; }
 * 
 * ::first-line -- 选中块元素的首行
 *   p::first-line { text-transform: uppercase }
 * 
 * ::selection -- 光标选中的文本
 *   p::selection { color: white; background-color: blue; }
 * 
 * ::before -- 创建伪元素，放置为第一个子元素
 * ::after -- 创建伪元素，放置为最后一个子元素
 *   注: before 和 after 必须配合 content 使用
 *   div::before { content: "««««««««««"; color: blue;}
 *   div::after { content: "»»»»»»»»»»"; color: red; }
 */
```

## 选择器的权重

```js
/**
 * 选择器权重
 *   元素,伪元素选择器    0 0 0 1
 *   类,伪类,属性选择器   0 0 1 0
 *   id选择器           0 1 0 0
 *   内联样式           1 0 0 0
 * 
 * 权重计算规则
 *   1.通配选择器('*')，关系运算符('+', '~', '>', ' ')和否定伪类(':not()')不纳入计算
 *   2.元素默认样式和继承样式没有权重，能被任意选择器中的样式覆盖
 *   3.样式冲突，则取最高权重的样式表现，如果最高权重也相同，则取离结构最近的样式表现
 *   4.选择器的累加不会超过最大的数量级，例如无论多少个类选择器叠加也不会超过id选择器
 *   5.并集选择器应单独计算每个选择器，最后取权重最高的一个为并集选择器的权重值
 *   6.样式后添加 !important，会使该样式获得最高权重，直接超过内联样式
 * 
 * 权重计算举例
 *   * { ... }   0000
 *   ul ol { ... }   0002
 *   ul ol+li  { ... }   0003
 *   a:hover { ... }   0011
 *   div.box h1#title { ... }   0112
 *   #box1 #box2 p { ... }   0201
 *   #box1 div.box2 #box3 p { ... }   0212
 * 
 * 伪类的优先级 -- 超链接的伪类共有四个，且优先级相同，所以要保证严格的顺序，防止出现样式覆盖
 *   a:link --> a:visited --> a:hover --> a:active
 */
```
